const usernameInput = document.querySelector('#username');
const loginBtn = document.querySelector('#loginBtn');
const userStatus = document.querySelector('#userStatus');
const roomTitle = document.querySelector('#roomTitle');
const roomButtons = document.querySelectorAll('.room');
const messagesBox = document.querySelector('#messages');
const messageForm = document.querySelector('#messageForm');
const messageInput = document.querySelector('#messageInput');
const clearBtn = document.querySelector('#clearBtn');

let currentUser = localStorage.getItem('chat_username') || '';
let currentRoom = localStorage.getItem('chat_room') || 'general';

const roomNames = {
  general: 'اتاق عمومی',
  university: 'اتاق دانشگاه',
  project: 'اتاق پروژه'
};

function storageKey() {
  return `messages_${currentRoom}`;
}

function getMessages() {
  const raw = localStorage.getItem(storageKey());
  return raw ? JSON.parse(raw) : [];
}

function saveMessages(messages) {
  localStorage.setItem(storageKey(), JSON.stringify(messages));
}

function renderMessages() {
  const messages = getMessages();
  messagesBox.innerHTML = '';

  if (messages.length === 0) {
    messagesBox.innerHTML = '<p class="empty">هنوز پیامی در این اتاق وجود ندارد.</p>';
    return;
  }

  messages.forEach((message) => {
    const div = document.createElement('div');
    div.className = message.sender === currentUser ? 'message mine' : 'message';

    const meta = document.createElement('span');
    meta.className = 'meta';
    meta.textContent = `${message.sender} - ${message.time}`;

    const text = document.createElement('span');
    text.textContent = message.text;

    div.append(meta, text);
    messagesBox.appendChild(div);
  });

  messagesBox.scrollTop = messagesBox.scrollHeight;
}

function updateUserStatus() {
  usernameInput.value = currentUser;
  userStatus.textContent = currentUser
    ? `کاربر فعلی: ${currentUser}`
    : 'ابتدا نام کاربری را وارد کنید.';
}

function switchRoom(room) {
  currentRoom = room;
  localStorage.setItem('chat_room', room);
  roomTitle.textContent = roomNames[room];

  roomButtons.forEach((button) => {
    button.classList.toggle('active', button.dataset.room === room);
  });

  renderMessages();
}

loginBtn.addEventListener('click', () => {
  const username = usernameInput.value.trim();
  if (!username) {
    alert('نام کاربری را وارد کنید.');
    return;
  }

  currentUser = username;
  localStorage.setItem('chat_username', username);
  updateUserStatus();
});

roomButtons.forEach((button) => {
  button.addEventListener('click', () => switchRoom(button.dataset.room));
});

messageForm.addEventListener('submit', (event) => {
  event.preventDefault();

  if (!currentUser) {
    alert('قبل از ارسال پیام، نام کاربری را وارد کنید.');
    return;
  }

  const text = messageInput.value.trim();
  if (!text) return;

  const messages = getMessages();
  messages.push({
    sender: currentUser,
    text,
    time: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })
  });

  saveMessages(messages);
  messageInput.value = '';
  renderMessages();
});

clearBtn.addEventListener('click', () => {
  if (confirm('همه پیام‌های این اتاق پاک شود؟')) {
    localStorage.removeItem(storageKey());
    renderMessages();
  }
});

updateUserStatus();
switchRoom(currentRoom);
